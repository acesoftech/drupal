<?php
namespace Drupal\student_registration\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Database;

class StudentRegistrationForm extends FormBase {
  public function getFormId() {
    return 'student_registration_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['name'] = [
      '#type' => 'textfield',
      '#title' => 'Student Name',
      '#required' => TRUE,
    ];
    $form['email'] = [
      '#type' => 'email',
      '#title' => 'Email',
      '#required' => TRUE,
    ];
    $form['course'] = [
      '#type' => 'textfield',
      '#title' => 'Course Name',
      '#required' => TRUE,
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => 'Register',
    ];
    return $form;
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $connection = Database::getConnection();
    $connection->insert('student_registration')->fields([
      'name' => $form_state->getValue('name'),
      'email' => $form_state->getValue('email'),
      'course' => $form_state->getValue('course'),
      'created' => REQUEST_TIME,
    ])->execute();
    \Drupal::messenger()->addMessage('Student Registered Successfully.');
  }
}
