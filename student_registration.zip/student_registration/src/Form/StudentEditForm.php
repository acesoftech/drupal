<?php
namespace Drupal\student_registration\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Database;
use Symfony\Component\HttpFoundation\RedirectResponse;

class StudentEditForm extends FormBase {
  protected $id;

  public function getFormId() {
    return 'student_edit_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state, $id = NULL) {
    $this->id = $id;
    $record = Database::getConnection()->select('student_registration', 's')
      ->fields('s')
      ->condition('id', $id)
      ->execute()->fetchObject();

    $form['name'] = [
      '#type' => 'textfield',
      '#title' => 'Student Name',
      '#default_value' => $record->name,
      '#required' => TRUE,
    ];
    $form['email'] = [
      '#type' => 'email',
      '#title' => 'Email',
      '#default_value' => $record->email,
      '#required' => TRUE,
    ];
    $form['course'] = [
      '#type' => 'textfield',
      '#title' => 'Course Name',
      '#default_value' => $record->course,
      '#required' => TRUE,
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => 'Update',
    ];
    return $form;
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    Database::getConnection()->update('student_registration')
      ->fields([
        'name' => $form_state->getValue('name'),
        'email' => $form_state->getValue('email'),
        'course' => $form_state->getValue('course'),
      ])
      ->condition('id', $this->id)
      ->execute();

    \Drupal::messenger()->addMessage('Student record updated.');
    $response = new RedirectResponse('/admin/config/student-registration/list');
    $response->send();
  }
}
