(function ($, Drupal) {
  Drupal.behaviors.myThemeBehavior = {
    attach: function (context, settings) {
      console.log('Custom JS is working in MyTheme');
    }
  };
})(jQuery, Drupal);
