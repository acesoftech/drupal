<?php
namespace Drupal\student_registration\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\Core\Link;

class StudentController extends ControllerBase {
  public function studentList() {
    $header = ['ID', 'Name', 'Email', 'Course', 'Operations'];
    $rows = [];
    $results = Database::getConnection()->select('student_registration', 's')
      ->fields('s', ['id', 'name', 'email', 'course'])
      ->execute();
    foreach ($results as $row) {
      $edit_url = Url::fromRoute('student_registration.edit', ['id' => $row->id]);
      $delete_url = Url::fromRoute('student_registration.delete', ['id' => $row->id]);
      $rows[] = [
        $row->id,
        $row->name,
        $row->email,
        $row->course,
        [
          'data' => [
            '#markup' => Link::fromTextAndUrl('Edit', $edit_url)->toString() . ' | ' .
                        Link::fromTextAndUrl('Delete', $delete_url)->toString(),
          ],
        ],
      ];
    }
    return [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => $rows,
      '#empty' => 'No students registered yet.',
    ];
  }

  public function deleteStudent($id) {
    Database::getConnection()->delete('student_registration')
      ->condition('id', $id)
      ->execute();
    \Drupal::messenger()->addMessage('Student deleted successfully.');
    return $this->redirect('student_registration.list');
  }
}
